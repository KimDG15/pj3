from django.shortcuts import render
from .models import Book, Exhibition, ExhibitionPlace
#from yogi6.models import User

def home(request):
    dic = {}
    '''
    book = Book.objects.filter(book_id=4)[0]
    dic['id'] = book.book_id
    dic['name'] = book.name
    dic['writer'] = book.writer
    dic['description'] = book.description
    '''

    '''
    exhibition = Exhibition.objects.filter(exhibition_id=5)[0]
    dic['exhibition_id'] = exhibition.exhibition_id
    dic['name'] = exhibition.name
    dic['poster_link'] = exhibition.poster_link
    return render(request,'home.html', {'data':dic})
    '''
    req_dic = {}
    for i in range(1, 50):
        dic={}
        exhibition = Exhibition.objects.filter(exhibition_id=i)[0]
        dic['exhibition_id'] = exhibition.exhibition_id
        dic['name'] = exhibition.name
        dic['poster_link'] = exhibition.poster_link
        req_dic[f'{i}'] = dic
    #print(req_dic)
    return render(request,'home.html', {'data':req_dic})



def detail(request, id):
    print(id)
    dic={}
    target_exhibition = Exhibition.objects.filter(exhibition_id=id)[0]
    dic['exhibition_id'] = target_exhibition.exhibition_id
    dic['name'] = target_exhibition.name
    dic['poster_link'] = target_exhibition.poster_link
    dic['detail_place'] = target_exhibition.detail_place
    dic['description'] = target_exhibition.description
    dic['start_period'] = target_exhibition.start_period
    dic['end_period'] = target_exhibition.end_period
    dic['place_id'] = target_exhibition.place_id
    return render(request, 'detail.html', {'data':dic})