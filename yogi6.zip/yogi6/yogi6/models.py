# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from django.contrib.auth.models import AbstractUser
'''
class Yogi6User(AbstractUser):
    select_keyword1 = models.CharField(max_length=150, blank=True)
    select_keyword2 = models.CharField(max_length=150, blank=True)
    profile_msg = models.TextField(max_length=500, blank=True)
    birth_date = models.DateField(null=True, blank=True)
'''

class Book(models.Model):
    book_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=500, blank=True, null=True)
    writer = models.CharField(max_length=500, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    keyword = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'book'


class Exhibition(models.Model):
    exhibition_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=500, blank=True, null=True)
    poster_link = models.CharField(max_length=500, blank=True, null=True)
    detail_place = models.CharField(max_length=500, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    start_period = models.DateField(blank=True, null=True)
    end_period = models.DateField(blank=True, null=True)
    place_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'exhibition'


class ExhibitionPlace(models.Model):
    place_id = models.AutoField(primary_key=True)
    post_num = models.CharField(max_length=45, blank=True, null=True)
    name = models.CharField(max_length=500, blank=True, null=True)
    address = models.CharField(max_length=500, blank=True, null=True)
    x = models.FloatField(blank=True, null=True)
    y = models.FloatField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'exhibition_place'
